#!/usr/bin/env python
# coding: utf-8

# In[1]:



import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')


# # installation of libraries above
# 

# # loading the dataset

# In[28]:


train = pd.read_csv(r'C:\Users\tusha\Downloads\train_s3TEQDk.csv')
test = pd.read_csv(r'C:\Users\tusha\Downloads\test_mSzZ8RL.csv')


# In[3]:


train.shape, test.shape


# In[4]:


train['source'] = 'train'
test['source'] = 'test'
data = pd.concat([train,test],ignore_index=True)


# # Checking the null VAlue

# In[6]:


data.isnull().sum()


# In[7]:


data['Credit_Product'].value_counts()


# In[8]:


data['Credit_Product'].replace(np.nan,'Yes',inplace=True)


# # checking the avg account balance 

# In[9]:


sns.distplot(data['Avg_Account_Balance'])
plt.show()


# In[10]:


data['Avg_Account_Balance'] = np.log(data['Avg_Account_Balance'])
sns.distplot(data['Avg_Account_Balance'])
plt.show()


# # cleaning the data

# In[11]:


train = data.loc[data['source']=="train"]
test = data.loc[data['source']=="test"]

#Drop unnecessary columns:
test.drop(['Is_Lead','source'],axis=1,inplace=True)
train.drop('source',axis=1,inplace=True)


# In[12]:


train.drop('ID',axis=1,inplace=True)
test.drop("ID",axis=1,inplace = True)


# In[13]:


train.dtypes


# # Preprocessing the dataset

# In[14]:


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
var_mod = ['Gender','Region_Code','Occupation','Channel_Code','Credit_Product','Is_Active']
for i in var_mod:
    train[i] = le.fit_transform(train[i])
    test[i] = le.fit_transform(test[i])


# In[15]:


X = train.drop('Is_Lead',axis=1)
y = train['Is_Lead']


# In[16]:


from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import roc_auc_score

def cross_val(X, y, model, params, folds=9):

    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=21)
    for fold, (train_idx, test_idx) in enumerate(skf.split(X, y)):
        print(f"Fold: {fold}")
        x_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
        x_test, y_test = X.iloc[test_idx], y.iloc[test_idx]

        alg = model(**params)
        alg.fit(x_train, y_train,
                eval_set=[(x_test, y_test)],
                early_stopping_rounds=100,
                verbose=400)

        pred = alg.predict_proba(x_test)[:, 1]
        roc_score = roc_auc_score(y_test, pred)
        print(f"roc_auc_score: {roc_score}")
        print("-"*50)
    
    return alg


# In[17]:


lgb_params= {'learning_rate': 0.045, 
             'n_estimators': 20000, 
             'max_bin': 94,
             'num_leaves': 10, 
             'max_depth': 27, 
             'reg_alpha': 8.457, 
             'reg_lambda': 6.853, 
             'subsample': 0.749}


# # Building the ML MOdel (LGBM)

# In[18]:


from lightgbm import LGBMClassifier
lgb_model = cross_val(X, y, LGBMClassifier, lgb_params)


# In[19]:


xgb_params= {'n_estimators': 20000, 
             'max_depth': 6, 
             'learning_rate': 0.0201, 
             'reg_lambda': 29.326, 
             'subsample': 0.818, 
             'colsample_bytree': 0.235, 
             'colsample_bynode': 0.820, 
             'colsample_bylevel': 0.453}


# # Aplying the XGB MOdel on dtaset

# In[20]:


from xgboost import XGBClassifier
xgb_model = cross_val(X, y, XGBClassifier, xgb_params)


# In[21]:


cat_params= {'n_estimators': 20000, 
                  'depth': 4, 
                  'learning_rate': 0.023, 
                  'colsample_bylevel': 0.655, 
                  'bagging_temperature': 0.921, 
                  'l2_leaf_reg': 10.133}


# # Applying the catboost Algo

# In[23]:


from catboost import CatBoostClassifier
cat_model = cross_val(X, y, CatBoostClassifier, cat_params)


# In[24]:


pred_test_lgb = lgb_model.predict_proba(test)[:,1]
pred_test_xgb = xgb_model.predict_proba(test)[:,1]
pred_test_cat = cat_model.predict_proba(test)[:,1]
prediction = (pred_test_lgb + pred_test_cat+pred_test_xgb)/3


# In[25]:


sample_submission = pd.read_csv(r'C:\Users\tusha\Downloads\sample_submission.csv')


# In[26]:


sample_submission['Is_Lead'] = prediction
sample_submission.to_csv(f'submission.csv',index=False)


# # Gathering the value

# In[27]:


sample_submission['Is_Lead'] = pred_test_lgb
sample_submission.to_csv(f'pred_test_lgb.csv',index=False)

sample_submission['Is_Lead'] = pred_test_xgb
sample_submission.to_csv(f'pred_test_xgb.csv',index=False)

sample_submission['Is_Lead'] = pred_test_cat
sample_submission.to_csv(f'pred_test_cat.csv',index=False)

